Program yang di-run adalah main.py

Library berikut merupakan library yang digunakan pada program (beberapa perlu diinstal terlebih dahulu):
- os
- threading
- time
- cv2
- customtkinter
- tkinter
- PIL
- pydub
- datetime

Font yang perlu diinstal terlebih dahulu:
- Gotham
    https://www.dafontfree.co/download/spotify/
- Gotham Black
    https://www.dafontfree.co/download/spotify/